var youtube = "https://www.youtube.com/channel/UC5p9eyIG7vQyEatLJvxYj7A";
var twitter = "https://twitter.com/Faustino1103";
var password = "dorian";
var instagram = "https://www.instagram.com/joaosantos1103/";
var github = "https://replit.com/@faustinuuu";

whois = [
  "<br>",
  "Hey, I'm Faustino!👋",
  "I'm an amateur software developer and professional no-lifer.",
  "I spend most of my time gaming or doing stupid and useless projects like this one.",
  "I'm from Portugal and in this moment I'm living in Aveiro.",
  "<br>"
];

thought = [
    "<br>",
    "If I may? I would like to pose an interesting question.",
    "Are all human beings truly equal? This days everywhere you go",
    "there's a talk about fight for equality.",
    "As a wise man once said...",
    "Heaven does not create once person above or below another.",
    "People like to throw his words around.",
    "That's not the whole quote.",
    "He goes on to say that while we are all equal at birth.",
    "Pretty soon... Things begin to change. Academic effor is",
    "what sets some people apart, to rise above the others.",
    "At any rate, humans change over time based on their actions, truth be told,",
    "at the end of the day, equality is just a <span class=\"command\">'FANTASY'</span><span class=\"color2\">.",
    "<br>"
  ];

whoami = [
  "<br>",
  "The paradox of “Who am I?” is: we never know, but, we constantly find out.",
  "<br>"
];

social = [
  "<br>",
  'youtube        <a href="' + youtube + '" target="_blank">youtube/faustino' + "</a>",
  'twitter        <a href="' + twitter + '" target="_blank">twitter/faustino' + '</a>',
  'instagram      <a href="' + instagram + '" target="_blank">instagram/faustino' + '</a>',
  'replit         <a href="' + github + '" target="_blank">replit/faustino' + "</a>",
  "<br>"
];

secret = [
  "<br>",
  '<span class="command">sudo</span>           Only use if you\'re admin',
  "<br>"
];


help = [
  "<br>",
  '<span class="command">whois</span>          Who is Faustino?',
  '<span class="command">social</span>         Display social networks',
  '<span class="command">history</span>        View command history',
  '<span class="command">help</span>           You obviously already know what this does',
  '<span class="command">clear</span>          Clear terminal',
  '<span class="command">banner</span>         Display the header',
  "<br>",
];

banner = [
  '<span class="index">faustino.cc (JS) Not A Corporation. All rights reserved.</span>',
  "______              _   _             ",
  "|  ___|            | | (_)            ",
  "| |_ __ _ _   _ ___| |_ _ _ __   ___  ",
  "|  _/ _` | | | / __| __| | '_ \\ / _ \\ ",
  "| || (_| | |_| \\__ \\ |_| | | | | (_) |",
  "\\_| \\__,_|\\__,_|___/\\__|_|_| |_|\\___/ ",
  "                                             ",
  '<span class="color2">Welcome to my interactive web terminal, feel free to explore.</span>',
  "<span class=\"color2\">For a list of available commands, type</span> <span class=\"command\">'help'</span><span class=\"color2\">.</span>",
];
